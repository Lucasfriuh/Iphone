package iphone;

import aparelhotelefônico.AparelhoTelefônico;
import reprodutormusical.ReprodutorMusical;

public class Iphone implements AparelhoTelefônico, Navegador.NavegadorNaInternet, ReprodutorMusical {

    @Override
    public void ligar() {
        System.out.println("Ligando o iPhone...");
    }

    @Override
    public void atender() {
        System.out.println("Atendendo a chamada no iPhone...");
    }

    @Override
    public void iniciarCorreioVoz() {
        System.out.println("Iniciando correio de voz no iPhone...");
    }

    @Override
    public void exibirPagina() {
        System.out.println("Exibindo a página no navegador do iPhone...");
    }

    @Override
    public void adicionarNovaAba() {
        System.out.println("Adicionando nova aba no navegador do iPhone...");
    }

    @Override
    public void atualizarPagina() {
        System.out.println("Atualizando a página no navegador do iPhone...");
    }

    @Override
    public void tocar() {
        System.out.println("Reproduzindo música no iPhone...");
    }

    @Override
    public void pausar() {
        System.out.println("Pausando a música no iPhone...");
    }

    @Override
    public void selecionarMusica() {
        System.out.println("Selecionando música no iPhone...");
    }
}
