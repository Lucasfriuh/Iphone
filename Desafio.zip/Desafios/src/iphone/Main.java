package iphone;

public class Main {
    public static void main(String[] args) {
        Iphone celular = new Iphone();
        
        // Usando funções de AparelhoTelefônico
        celular.ligar();
        celular.atender();
        celular.iniciarCorreioVoz();
        
        // Usando funções de NavegadorNaInternet
        celular.exibirPagina();
        celular.adicionarNovaAba();
        celular.atualizarPagina();
        
        // Usando funções de ReprodutorMusical
        celular.tocar();
        celular.pausar();
        celular.selecionarMusica();
    }
}
