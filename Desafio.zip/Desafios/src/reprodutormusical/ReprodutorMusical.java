package reprodutormusical;

public interface ReprodutorMusical {
    void tocar();
    void pausar();
    void selecionarMusica();
}
