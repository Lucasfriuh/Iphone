package Navegador;

public interface NavegadorNaInternet {
    void exibirPagina();
    void adicionarNovaAba();
    void atualizarPagina();
}
