package aparelhotelefônico;

public interface AparelhoTelefônico {
    void ligar();
    void atender();
    void iniciarCorreioVoz();
}
